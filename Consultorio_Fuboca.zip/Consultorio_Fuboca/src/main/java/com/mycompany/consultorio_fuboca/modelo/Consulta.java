/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.consultorio_fuboca.modelo;

/**
 *
 * @author aluno.den
 */
import java.time.LocalDate;
import java.time.LocalTime;

public class Consulta {
    private int idConsulta;
    private int idPaciente;
    private int idMedico;
    private LocalDate data;
    private LocalTime hora;
    private String observacao;
    
    private String nomePaciente;
    private String nomeMedico;

    public Consulta() {
        
    }
    
    public Consulta(int idPaciente, int idMedico,LocalDate data, LocalTime hora,String observacao ) {
       
        this.idPaciente = idPaciente;
        this.idMedico = idMedico;
        this.data = data;
        this.hora = hora;
        this.observacao = observacao;
    }

    public Consulta(int idConsulta,int idPaciente, int idMedico , LocalDate data, LocalTime hora, String observacao) {
        this.idConsulta = idConsulta;
        this.idPaciente = idPaciente;
        this.idMedico = idMedico;
        this.data = data;
        this.hora = hora;
        this.observacao = observacao;
       
    }
    
    public Consulta(int idConsulta, LocalDate data, LocalTime hora, String observacao){
        this.idConsulta = idConsulta;
        this.data = data;
        this.hora = hora;
        this.observacao = observacao;
    }

    public int getIdConsulta() {
        return idConsulta;
    }

    public void setIdConsulta(int idConsulta) {
        this.idConsulta = idConsulta;
    }

    public int getIdPaciente() {
        return idPaciente;
    }

    public void setIdPaciente(int idPaciente) {
        this.idPaciente = idPaciente;
    }

    public int getIdMedico() {
        return idMedico;
    }

    public void setIdMedico(int idMedico) {
        this.idMedico = idMedico;
    }

    public LocalDate getData() {
        return data;
    }

    public void setData(LocalDate data) {
        this.data = data;
    }

    public LocalTime getHora() {
        return hora;
    }

    public void setHora(LocalTime hora) {
        this.hora = hora;
    }

    public String getObservacao() {
        return observacao;
    }

    public void setObservacao(String observacao) {
        this.observacao = observacao;
    }

    public String getNomePaciente() {
        return nomePaciente;
    }

    public void setNomePaciente(String nomePaciente) {
        this.nomePaciente = nomePaciente;
    }

    public String getNomeMedico() {
        return nomeMedico;
    }

    public void setNomeMedico(String nomeMedico) {
        this.nomeMedico = nomeMedico;
    }
    
    
}
    