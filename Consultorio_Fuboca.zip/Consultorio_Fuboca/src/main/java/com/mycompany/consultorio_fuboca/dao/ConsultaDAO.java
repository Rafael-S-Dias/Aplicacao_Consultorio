/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.consultorio_fuboca.dao;

/**
 *
 * @author aluno.den
 */

import com.mycompany.consultorio_fuboca.connectMySQL.ConexaoMySQL;
import com.mycompany.consultorio_fuboca.modelo.Consulta;
import java.sql.*;
import java.util.ArrayList;

public class ConsultaDAO {

    public void inserir(Consulta consulta) {
        String sql = "INSERT INTO consulta (nomePaciente, nomeMedico, data, hora,observacao ) VALUES (?, ?, ?, ?, ?)";
        try (Connection conn = ConexaoMySQL.conectar();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, consulta.getnomePaciente());
            stmt.setString(2, consulta.getnomeMedico());
            stmt.setDate(3, Date.valueOf(consulta.getData()));
            stmt.setTime(4, Time.valueOf(consulta.getHora()));
            stmt.setString(5, consulta.getObservacao());
            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public ArrayList<Consulta> listar() {
        ArrayList<Consulta> lista = new ArrayList<>();
        String sql = "SELECT * FROM consulta";
        try (Connection conn = ConexaoMySQL.conectar();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                Consulta c = new Consulta(
                    rs.getInt("idConsulta"), 
                    rs.getString("Paciente"),
                    rs.getString("Medico"),
                    rs.getDate("data").toLocalDate(),
                    rs.getTime("hora").toLocalTime(),
                    rs.getString("observacao")
                   
                );
                lista.add(c);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return lista;
    }

    public void atualizar(Consulta consulta) {
        String sql = "UPDATE consulta SET nomePaciente = ?, nomeMedico = ?, data = ?, hora = ?, observacao = ? WHERE idConsulta = ?";
        try (Connection conn = ConexaoMySQL.conectar();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
    
            stmt.setString(1, consulta.getnomePaciente());
            stmt.setString(2, consulta.getnomeMedico());
            stmt.setDate(3, Date.valueOf(consulta.getData()));
            stmt.setTime(4, Time.valueOf(consulta.getHora()));
            stmt.setString(5, consulta.getObservacao());
           
            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void remover(int idConsulta) {
        String sql = "DELETE FROM consulta WHERE idConsulta = ?";
        try (Connection conn = ConexaoMySQL.conectar();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, idConsulta);
            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    
     public ArrayList<Consulta> buscarPorData(String data) {
        ArrayList<Consulta> lista = new ArrayList<>();
        String sql = "SELECT * FROM consulta WHERE Data LIKE ?";

        try (Connection conn = ConexaoMySQL.conectar();
            PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, "%" + data + "%");
            ResultSet rs = stmt.executeQuery();

            while (rs.next()) {
                Consulta c = new Consulta(
                    rs.getInt("idConsulta"),
                    rs.getString("nomePaciente"),
                    rs.getString("nomeMedico"),
                    rs.getDate("data").toLocalDate(),
                    rs.getTime("hora").toLocalTime(),
                    rs.getString("observacao")
                );
                lista.add(c);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return lista;
    }
    /*
     public ArrayList<Paciente> buscarPorNomePaciente(String idPaciente) {
        ArrayList<Paciente> lista = new ArrayList<>();
        String sql = "SELECT * FROM paciente WHERE idPaciente LIKE ?";

        try (Connection conn = ConexaoMySQL.conectar();
            PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, "%" + idPaciente + "%");
            ResultSet rs = stmt.executeQuery();

            while (rs.next()) {
                Paciente p = new Paciente(
                    rs.getInt("idPaciente"),
                    rs.getString("cpf"),
                    rs.getString("ddd"),
                    rs.getString("numTelefone"),
                    rs.getString("primeiroNomePaciente"),
                    rs.getString("nomeDoMeioPaciente"),
                    rs.getString("ultimoNomePaciente")
                );
                lista.add(p);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return lista;
    }
*/
}