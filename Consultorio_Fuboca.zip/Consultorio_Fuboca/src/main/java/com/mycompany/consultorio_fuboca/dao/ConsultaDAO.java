/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.consultorio_fuboca.dao;

/**
 *
 * @author aluno.den
 */

import com.mycompany.consultorio_fuboca.connectMySQL.ConexaoMySQL;
import com.mycompany.consultorio_fuboca.modelo.Consulta;
import java.sql.*;
import java.util.ArrayList;

public class ConsultaDAO {

    public void inserir(Consulta consulta) {
        String sql = "INSERT INTO consulta (Data, Hora, Observação, Paciente_IdPaciente, Medico_idMedico) VALUES (?, ?, ?, ?, ?)";
                /*Paciente_idPaciente, Medico_idMedico, data, hora,observacao ) VALUES (?, ?, ?, ?, ?)";
        try (Connection conn = ConexaoMySQL.conectar();
            PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, consulta.getIdPaciente());
            stmt.setInt(2, consulta.getIdMedico());
            stmt.setDate(3, Date.valueOf(consulta.getData()));
            stmt.setTime(4, Time.valueOf(consulta.getHora()));
            stmt.setString(5, consulta.getObservacao());*/
        try (Connection conn = ConexaoMySQL.conectar();
         PreparedStatement stmt = conn.prepareStatement(sql)) {
        
        stmt.setDate(1, java.sql.Date.valueOf(consulta.getData()));
        stmt.setTime(2, java.sql.Time.valueOf(consulta.getHora()));
        stmt.setString(3, consulta.getObservacao());
        stmt.setInt(4, consulta.getIdPaciente());
        stmt.setInt(5, consulta.getIdMedico());
        
        stmt.executeUpdate();
        System.out.println("Consulta inserida com sucesso!");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

   public ArrayList<Consulta> listar() {
    ArrayList<Consulta> lista = new ArrayList<>();
   
    // Consulta SQL com JOIN para pegar os nomes dos pacientes e médicos
    String sql = "SELECT " +
                 "Consulta.idConsulta, " +
                 "Consulta.Data, " +
                 "Consulta.Hora, " +
                 "Consulta.Observação, " +
                 "CONCAT(Paciente.PrimeiroNomePaciente, ' ', IFNULL(Paciente.NomeDoMeioPaciente, ''), ' ', Paciente.UltimoNomePaciente) AS Paciente, " +
                 "CONCAT(Medico.PrimeiroNomeMedico, ' ', IFNULL(Medico.NomeDoMeioMedico, ''), ' ', Medico.UltimoNomeMedico) AS Medico " +
                 "FROM Consulta " +
                 "JOIN Paciente ON Consulta.Paciente_IdPaciente = Paciente.IdPaciente " +
                 "JOIN Medico ON Consulta.Medico_idMedico = Medico.idMedico";
   
    try (Connection conn = ConexaoMySQL.conectar();
         Statement stmt = conn.createStatement();
         ResultSet rs = stmt.executeQuery(sql)) {
       
        while (rs.next()) {

            Consulta c = new Consulta(
                rs.getInt("idConsulta"),
                rs.getDate("Data").toLocalDate(),
                rs.getTime("Hora").toLocalTime(),
                rs.getString("Observação")
            );
            
            c.setNomePaciente(rs.getString("Paciente"));
            c.setNomeMedico(rs.getString("Medico"));
            
            lista.add(c); 
        }
    } catch (SQLException e) {
        e.printStackTrace();
    }
   
    return lista;
}


    public void atualizar(Consulta consulta) {
        String sql = "UPDATE consulta SET idPaciente = ?, idMedico = ?, data = ?, hora = ?, observacao = ? WHERE idConsulta = ?";
        try (Connection conn = ConexaoMySQL.conectar();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
    
            stmt.setInt(1, consulta.getIdPaciente());
            stmt.setInt(2, consulta.getIdMedico());
            stmt.setDate(3, Date.valueOf(consulta.getData()));
            stmt.setTime(4, Time.valueOf(consulta.getHora()));
            stmt.setString(5, consulta.getObservacao());
           
            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void remover(int idConsulta) {
        String sql = "DELETE FROM consulta WHERE idConsulta = ?";
        try (Connection conn = ConexaoMySQL.conectar();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, idConsulta);
            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    
     public ArrayList<Consulta> buscarPorData(String data) {
    ArrayList<Consulta> lista = new ArrayList<>();

    // Converte "dd/MM/yyyy" para "yyyy-MM-dd"
    String dataConvertida;
    try {
        java.time.format.DateTimeFormatter formatterEntrada = java.time.format.DateTimeFormatter.ofPattern("dd/MM/yyyy");
        java.time.LocalDate dataFormatada = java.time.LocalDate.parse(data, formatterEntrada);
        dataConvertida = dataFormatada.toString(); // yyyy-MM-dd
    } catch (Exception e) {
        System.out.println("Formato de data inválido. Use dd/MM/yyyy.");
        return lista; // retorna lista vazia
    }

    String sql = "SELECT " +
                 "Consulta.idConsulta, " +
                 "Consulta.Data, " +
                 "Consulta.Hora, " +
                 "Consulta.Observação, " +
                 "CONCAT(Paciente.PrimeiroNomePaciente, ' ', IFNULL(Paciente.NomeDoMeioPaciente, ''), ' ', Paciente.UltimoNomePaciente) AS Paciente, " +
                 "CONCAT(Medico.PrimeiroNomeMedico, ' ', IFNULL(Medico.NomeDoMeioMedico, ''), ' ', Medico.UltimoNomeMedico) AS Medico " +
                 "FROM Consulta " +
                 "JOIN Paciente ON Consulta.Paciente_IdPaciente = Paciente.IdPaciente " +
                 "JOIN Medico ON Consulta.Medico_idMedico = Medico.idMedico " +
                 "WHERE Consulta.Data = ?";

    try (Connection conn = ConexaoMySQL.conectar();
         PreparedStatement stmt = conn.prepareStatement(sql)) {

        stmt.setString(1, dataConvertida);
        ResultSet rs = stmt.executeQuery();

        while (rs.next()) {
            Consulta c = new Consulta(
                rs.getInt("idConsulta"),
                rs.getDate("Data").toLocalDate(),
                rs.getTime("Hora").toLocalTime(),
                rs.getString("Observação")
            );

            c.setNomePaciente(rs.getString("Paciente"));
            c.setNomeMedico(rs.getString("Medico"));

            lista.add(c);
        }
    } catch (SQLException e) {
        e.printStackTrace();
    }

    return lista;
}

    
     public ArrayList<Consulta> buscarPorNome(String nome) {
    ArrayList<Consulta> lista = new ArrayList<>();
    String sql = "SELECT " +
                 "Consulta.idConsulta, " +
                 "Consulta.Data, " +
                 "Consulta.Hora, " +
                 "Consulta.Observação, " +
                 "Paciente.PrimeiroNomePaciente AS Paciente, " +
                 "Medico.PrimeiroNomeMedico AS Medico " +
                 "FROM Consulta " +
                 "JOIN Paciente ON Consulta.Paciente_IdPaciente = Paciente.IdPaciente " +
                 "JOIN Medico ON Consulta.Medico_idMedico = Medico.idMedico " +
                 "WHERE Paciente.PrimeiroNomePaciente = ? OR Medico.PrimeiroNomeMedico = ?"; // Usando = para buscar o primeiro nome exato

    try (Connection conn = ConexaoMySQL.conectar();
         PreparedStatement stmt = conn.prepareStatement(sql)) {

        // A consulta vai procurar pelo primeiro nome exato de paciente ou médico
        stmt.setString(1, nome); // Para pacientes
        stmt.setString(2, nome); // Para médicos

        ResultSet rs = stmt.executeQuery();

        while (rs.next()) {
            Consulta c = new Consulta(
                rs.getInt("idConsulta"),
                rs.getDate("Data").toLocalDate(),
                rs.getTime("Hora").toLocalTime(),
                rs.getString("Observação")
            );
            c.setNomePaciente(rs.getString("Paciente"));
            c.setNomeMedico(rs.getString("Medico"));
            lista.add(c);
        }
    } catch (SQLException e) {
        e.printStackTrace();
    }

    return lista;
}

}